﻿using DevExtreme.AspNet.Mvc.Builders;

namespace GridDragAndDropPOC.Extensions
{
    public static class DataGridBuilderExtension
    {
        /// <summary>
        /// Enables the drag and drop of cell value
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataGridBuilder"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static DataGridBuilder<T> EnableDragAndDropCellValue<T>(this DataGridBuilder<T> dataGridBuilder, bool enable = true)
        {
            if (!enable)
            {
                return dataGridBuilder;
            }

            return dataGridBuilder
                .OnInitialized("dxCellValueDragAndDrop.onInit")
                .OnCellClick("dxCellValueDragAndDrop.onCellClick")
                .OnCellHoverChanged("dxCellValueDragAndDrop.onCellHoverChanged");
        }

        /// <summary>
        /// Allow the drag and drop of cell value
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataGridColumn"></param>
        /// <param name="enable"></param>
        /// <returns></returns>
        public static DataGridColumnBuilder<T> AllowCellValueDragAndDrop<T>(this DataGridColumnBuilder<T> dataGridColumn, bool enable = true)
        {
            if (!enable)
            {
                return dataGridColumn.CssClass("dx-not-allow-column-to-drag-and-drop");
            }

            return dataGridColumn;
        }
    }
}

