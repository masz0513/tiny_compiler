﻿window.dxCellValueDragAndDrop = window.dxCellValueDragAndDrop || (function ($) {
    var selectedRange = {};
    var updatedCellsInfo = [];
    var isDragging = false;

    function onInit(e) {
        // allow dragging from indicator only (small square at the bottom right corner of the cell)
        e.component.element().on("mousedown", ".dx-dragndrop-cell-draggable-indicator", trackDragging);
        e.component.element().on("mouseup", updateCells);
        e.component.element().on("mouseleave", updateCells);
    }

    function onCellClick(e) {
        if (!e.column || isCellReadonly(e.component, e.column.index)) return;

        setTimeout(function () {
            try {
                selectedRange.startRowIndex = e.row.rowIndex;
                selectedRange.endRowIndex = e.row.rowIndex;

                selectedRange.startColumnIndex = e.columnIndex;
                selectedRange.endColumnIndex = e.columnIndex
            } catch(e) { }

            showSelection(e.component, selectedRange);
        }, 5);
    }

    function onCellHoverChanged(e) {
        setTimeout(function () {
            if (!e.column || isCellReadonly(e.component, e.column.index)) return;

            if (!isDragging) {
                return;
            }

            try {
                if (selectedRange.startRowIndex === undefined) {
                    selectedRange.startRowIndex = e.row.rowIndex;
                }

                if (selectedRange.startColumnIndex === undefined) {
                    selectedRange.startColumnIndex = e.columnIndex;
                }

                selectedRange.endRowIndex = e.row.rowIndex;
                selectedRange.endColumnIndex = e.columnIndex;
            } catch (e) { }

            showSelection(e.component, selectedRange);
        }, 5);
    }

    function trackDragging() {
        isDragging = true;
    }

    function showSelection(component, selectedRange) {
        if (selectedRange.startRowIndex < 0) return;

        component.element().find(".dx-dragndrop-cell-selected .dx-dragndrop-cell-draggable-indicator").remove();
        component.element().find(".dx-dragndrop-cell-selected").removeClass("dx-dragndrop-cell-selected");
        component.element().find(".dx-dragndrop-cell-edited").removeClass("dx-dragndrop-cell-edited");

        foreachRange(selectedRange, function (rowIndex, columnIndex) {
            selectCell(component, rowIndex, columnIndex);
        });
    }

    function selectCell(component, rowIndex, columnIndex) {
        var currSelectedCell = component.getCellElement(rowIndex, columnIndex);

        if (!currSelectedCell ||
            !isCellDragAndDropEnabled(currSelectedCell) ||
            isCellGroup(currSelectedCell)) {
            return;
        }

        if (rowIndex == selectedRange.startRowIndex) {
            currSelectedCell.addClass("dx-dragndrop-cell-selected");
            currSelectedCell.append('<div class="dx-dragndrop-cell-draggable-indicator"></div>');
            return;
        }

        currSelectedCell.addClass("dx-dragndrop-cell-edited");

        var currCellValue = currSelectedCell.text();

        var sourceCell = component.getCellElement(selectedRange.startRowIndex, columnIndex);
        var sourceCellValue = sourceCell.text();
        sourceCellValue = sourceCellValue ? sourceCellValue : sourceCell.find("input[type='text']").val();

        if (sourceCellValue !== currCellValue) {
            var cellExist = updatedCellsInfo.some(function (c, i) {
                return c.row == rowIndex && c.column == columnIndex;
            });

            if (!cellExist) {
                updatedCellsInfo.push({
                    value: sourceCellValue,
                    row: rowIndex,
                    column: columnIndex
                });
            }
        }
    }

    function foreachRange(selectedRange, func) {
        if (selectedRange.startRowIndex >= 0) {
            var minRowIndex = Math.min(selectedRange.startRowIndex, selectedRange.endRowIndex);
            var maxRowIndex = Math.max(selectedRange.startRowIndex, selectedRange.endRowIndex);
            var minColumnIndex = Math.min(selectedRange.startColumnIndex, selectedRange.endColumnIndex);
            var maxColumnIndex = Math.max(selectedRange.startColumnIndex, selectedRange.endColumnIndex);

            for (var rowIndex = minRowIndex; rowIndex <= maxRowIndex; rowIndex++) {
                for (var columnIndex = minColumnIndex; columnIndex <= maxColumnIndex; columnIndex++) {
                    func(rowIndex, columnIndex);
                }
            }
        }
    }

    function isCellReadonly(component, columnIndex) {
        var cell = component.columnOption(columnIndex);
        return cell == null || !cell.allowEditing;
    }

    function isCellDragAndDropEnabled(element) {
        return !element.hasClass("dx-not-allow-column-to-drag-and-drop");
    }

    function isCellGroup(element) {
        return element.hasClass("dx-group-cell") || element.hasClass("dx-datagrid-group-space")
            || element.hasClass("dx-datagrid-expand");
    }

    function cellsCleanup(updatedCellsInfo) {

        if (selectedRange.startColumnIndex > selectedRange.endColumnIndex) {
            swapRangeValue(selectedRange, 'startColumnIndex', 'endColumnIndex');
        }

        if (selectedRange.startRowIndex > selectedRange.endRowIndex) {
            swapRangeValue(selectedRange, 'startRowIndex', 'endRowIndex');
        }

        return updatedCellsInfo.filter(function (c) {
            return c.column >= selectedRange.startColumnIndex
                && c.column <= selectedRange.endColumnIndex
                && c.row >= selectedRange.startRowIndex
                && c.row <= selectedRange.endRowIndex
        });
    }

    function swapRangeValue(range, sourceKey, targetKey) {
        var temp = range[sourceKey];
        range[sourceKey] = range[targetKey];
        range[targetKey] = temp;
    }

    function updateCells() {
        isDragging = false;

        var gridComponent = $(this).dxDataGrid("instance");

        if (selectedRange.startRowIndex !== selectedRange.endRowIndex) {
            gridComponent.element().find(".dx-dragndrop-cell-selected .dx-dragndrop-cell-draggable-indicator").remove();
            gridComponent.element().find(".dx-dragndrop-cell-edited").removeClass("dx-dragndrop-cell-edited");
        }

        cellsCleanup(updatedCellsInfo).forEach(function (c) {
            gridComponent.cellValue(c.row, c.column, c.value);
        });

        selectedRange = {};
        updatedCellsInfo = [];
    }

    return {
        onInit: onInit,
        onCellClick: onCellClick,
        onCellHoverChanged: onCellHoverChanged
    };
})(jQuery);
