﻿$(function () {
    $("#gridContainer").dxDataGrid({
        "showBorders": true,
        "dataSource": {
            "store": DevExpress.data.AspNet.createStore({
                "key": "OrderID",
                "loadUrl": "/api/Orders",
                "updateUrl": "/api/Orders"
            })
        },
        "editing": {
            "mode": "batch",
            "allowUpdating": true,
            "startEditAction": "click",
            "selectTextOnEditStart": false
        },
        "columns": [{
            "dataField": "OrderID",
            "dataType": "number",
            "validationRules": [{
                "type": "required",
                "message": "The OrderID field is required."
            }],
            "cssClass": "dx-not-allow-column-to-drag-and-drop",
            "allowEditing": false,
            "width": 120.0,
            "alignment": "left"
        }, {
            "dataField": "OrderDate",
            "dataType": "date",
            "validationRules": [{
                "type": "required",
                "message": "The OrderDate field is required."
            }],
            "width": 120.0
        }, {
            "dataField": "CustomerName",
            "dataType": "string",
            "cssClass": "dx-not-allow-column-to-drag-and-drop"
        }, {
            "dataField": "ShipCountry",
            "dataType": "string"
        }, {
            "dataField": "ShipCity",
            "dataType": "string",
            "groupIndex": 3
        }, {
            "dataField": "Progress",
            "dataType": "string",
            "validationRules": [{
                "type": "required"
            }]
        }],
        "paging": {
            "pageSize": 30
        },
        "remoteOperations": true,
        "grouping": {
            "autoExpandAll": true
        },
        "onInitialized": dxCellValueDragAndDrop.onInit,
        "onCellClick": dxCellValueDragAndDrop.onCellClick,
        "onCellHoverChanged": dxCellValueDragAndDrop.onCellHoverChanged
    });
});