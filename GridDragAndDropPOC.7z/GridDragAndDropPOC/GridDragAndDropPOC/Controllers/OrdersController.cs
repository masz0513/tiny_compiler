using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using GridDragAndDropPOC.Models;
using DevExtreme.AspNet.Data;
using DevExtreme.AspNet.Mvc;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace GridDragAndDropPOC.Controllers {

    [Route("api/[controller]")]
    public class OrdersController : Controller {

        [HttpGet]
        public object Get(DataSourceLoadOptions loadOptions) {
            return DataSourceLoader.Load(SampleData.Orders, loadOptions);
        }

        [HttpPut]
        public IActionResult Put(int key, string values)
        {
            var order = SampleData.Orders.First(o => o.OrderID == key);
            JsonConvert.PopulateObject(values, order);
            return Ok();
        }
    }
}