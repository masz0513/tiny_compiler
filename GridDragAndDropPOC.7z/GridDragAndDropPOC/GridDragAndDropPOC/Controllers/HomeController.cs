using Microsoft.AspNetCore.Mvc;

namespace GridDragAndDropPOC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.SelectedMenuItem = "Default";
            return View();
        }

        public IActionResult Other(string viewName)
        {
            ViewBag.SelectedMenuItem = viewName;
            return View(viewName);
        }
    }
}
